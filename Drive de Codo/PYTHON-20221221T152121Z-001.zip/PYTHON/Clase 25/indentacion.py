a = int(input("Ingrese un valor: ")) # input siempre devuelve str, por eso lo convierto a int.

if a > 5:
    print("A es mayor a 5")

else:
    print("A es menor o igual a 5")

