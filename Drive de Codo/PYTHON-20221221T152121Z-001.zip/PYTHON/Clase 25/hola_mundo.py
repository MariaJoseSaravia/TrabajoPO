print("Hola Mundo")

# Comentario de Linea

"""
    Comentario de bloque

    (La verdad es que esto no es un comentario de bloque, es un docstring).   
"""

