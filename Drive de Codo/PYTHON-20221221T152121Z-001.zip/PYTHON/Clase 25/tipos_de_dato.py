a = 5                   # int
b = 3.14                # float
c = "Hola como estas"   # str
d = True                # bool
e = 3+1j                # complex

print(type(a), type(b), type(c), type(d), type(e))

