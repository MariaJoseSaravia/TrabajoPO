def saludar():
    print("HOLA MUNDO")


def funcion_x(a, b):
    # Resuevle un problema complejo

    # ...

    return a * b

def aplicar_iva(costo):
    """
        Aplica el Impuesto al Valor Agregado a un producto.
        se calcula como el total + el 21%.
    """
    resultado = costo * 1.21
    return resultado

saludar()
print(funcion_x(8, 5))

print("-------------------")

productos = {
    'Bici': 1000,
    'Moto': 2500,
    'Auto': 5000
}

for nombre, costo in productos.items():
    print("{}: ${}".format(nombre, aplicar_iva(costo)))

# Argumentos posicionales obligatorios
def funcion_1(a,b,c):
    print(a,b,c)


funcion_1("Hola", "Si", "Adios")
# funcion_1("No", "Piedra") # Error!

# Valores por defecto | parametros opcionales
def funcion_2(a=0, b="-"):
    print(a, b)

funcion_2()

funcion_2(8)

funcion_2(8, "Adios")

# Argumentos por nombre
def division(a, b):
    return a / b

print(division(4, 2))
print(division(2, 4))

print(division(a=4, b=2))
print(division(b=2, a=4))

# Las funciones SIEMPRE devuelven EXACTAMENTE 1 valor
resultado = saludar()
print(resultado)

# funcion que devuelve una tupla de valores
def cuadrado_cubo(a):
    return a ** 2, a ** 3, a ** 4

resultado = cuadrado_cubo(4)
print(resultado)

# Funciones Lambda
# Funciones anonimas

def cuadrado(a):
    return a ** 2

numeros = [1,2,3,4]

resultado = list(map(cuadrado, numeros))
print(resultado)

resultado = list(map(lambda x: x**2, numeros))
print(resultado)

# Ejemplo visto en clase
operaciones = {
    '+': lambda x, y: x + y,
    '-': lambda x, y: x - y,
    '**': lambda x, y: x ** y,
    '/': lambda x, y: x / y,
}

"""
print(list(operaciones.keys()))
operacion = input("Elija una operacion: ")

a = int(input("> "))
b = int(input("> "))

resultado = operaciones[operacion](a, b)
print(resultado)
"""