a = 5
b = 3.5

print(a + b)

c = input("Ingrese un valor: ")

print(c)

print("Adios")