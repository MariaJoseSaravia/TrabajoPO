# if evaula una condicion logica y toma una decision en funcion de si es verdadera o falsa.
# La condicion tambien es llamada como Guarda.

# En python los if no llevan parentesis.
a = 8

if a > 10:
    print("A es mayor que 10")

else:
    print("A es menor o igual que 10")

# La clausula else es opcional
if a == 8:
    print("A es igual a 8")

# En python no existe la clausula switch
# Pero si tenemos la clausula elif
dia = 4

if dia == 1:
    print("Lunes")
elif dia == 2:
    print("Martes")
elif dia == 3:
    print("Miercoles")
elif dia == 4:
    print("Jueves")
elif dia == 5:
    print("Viernes")
elif dia == 6:
    print("Sabado")
elif dia == 7:
    print("Domingo")
else:
    print("Eso no es un día")

print("Adios")