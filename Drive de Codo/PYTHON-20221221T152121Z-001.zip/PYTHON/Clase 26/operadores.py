a = 4
b = 2.5
c = 2

# Aritmeticos
print(a+b, a-b, a*b)

print("division real: ", a / b)
print("division entera: ", a // b)
print("resto division entera: ", a % c)

print("operador potencia: ", a ** b)
print("operador potencia (raiz cuadrada): ", 4 ** 0.5)

print("hola" + " como estas")
print("-" * 20)

# Operaciones y limitaciones con floats
print(0.1 + 0.2)

# Podemos usar round para mostrar una version del numero sin tantos decimales
# Esto no soluciona el problema de raiz, pero permite visualizar la informacion
# de forma simple.
print(round(0.1 + 0.2, 2))

print("----------------------------")

# Comparacion
print(a > b, a < b, a >= b, a <= b)
print(a == b)
print(a != b)

print("----------------------------")
# Logicos

# and
"""
    A and B dará Verdadero unicamente cuando ambos operandos son Verdaderos.
    Cualquier otro caso el resultado es Falso.
"""
# Tablas de verdad
"""
A | B | A and B
0 | 0 | 0
0 | 1 | 0
1 | 0 | 0
1 | 1 | 1
"""

# or
"""
    A or B será verdadero cuando al menos uno de los operandos sea verdadero.
    El resultado será falso unicamente cuando ambos operandos son falsos.
"""
# Tablas de verdad
"""
A | B | A or B
0 | 0 | 0
0 | 1 | 1
1 | 0 | 1
1 | 1 | 1 
"""

# not
"""
    Invertir el valor de la variable A
"""
# Tablas de verdad
"""
A | not A
0 | 1
1 | 0 
"""