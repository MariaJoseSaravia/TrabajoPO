/*
    1 = Lunes 
    ...
    7 = Domingo
*/
a = 99

switch(a) {
    case 1:
        console.log("Lunes");
        break;

    case 2:
        console.log("Martes");
        break;

    // ... 
    
    case 7:
        console.log("Domingo");
        break;

    default:
        console.log("Eso no es un dia");
        break;
};