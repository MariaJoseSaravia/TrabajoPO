# For
# Si sabemos con certeza la cantidad de veces que queremos iterar, debemos usar un for.

# range(desde, hasta) es con desde inclusive y hasta no inclusive. -> En notacion matematica: [0, 10)
# For "clasico"
for i in range(0, 10):
    print(i)

lista = [4,5,6]
# For each
for elemento in lista:
    print(elemento)

# While
# Cuando no sabemos y no podemos saber cuantas veces debe iterar un bucle, usamos el while.

correcto = False

while not correcto:
    respuesta = int(input("Ingrese un valor entre 1 y 10: "))
    correcto = 1 <= respuesta <= 10

print("Adios")

# Ojo con los bucles infinitos

i = 0
while i < 10:
    print(i)
    i += 1 # i = i + 1 # i++ no es valido

print("------------------------------------")

# break
for i in range(0, 10):
    print(i)
    if i == 5:
        break

    