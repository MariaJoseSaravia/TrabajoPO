class Cliente:
    def __init__(self, nombre):
        self.nombre = nombre
        self.monto = 0

    def depositar(self, cantidad):
        if cantidad <= 0:
            print("Solo puede hacer depositos positivos")
            return

        self.monto += cantidad

    def extraer(self, cantidad):
        if cantidad <= 0:
            print("Solo puede hacer retiros positivos")
            return

        if self.monto - cantidad < 0:
            print("No puede realizar esa extraccion")
            return

        self.monto -= cantidad

    def __str__(self):
        return f"{self.nombre} - Saldo en cuenta: ${self.monto}"


class Banco:
    def __init__(self, clientes=None):
        """
        if clientes is None:
            self.clientes = []

        else:
            self.clientes = clientes        
        """

        # if ternario
        self.clientes = [] if clientes is None else clientes

    def agregar_cliente(self, cliente):
        self.clientes.append(cliente)

    def listar_clientes(self):
        if not self.clientes:
            print("No hay clientes el en banco")

        for cliente in self.clientes:
            print(cliente)

    def total_ingresos(self):
        total = 0

        for cliente in self.clientes:
            total += cliente.monto

        print(f"Dinero en el banco: ${total}")

b1 = Banco()
b2 = Banco(
    [
        Cliente("Carlos"), 
        Cliente("Maria"), 
        Cliente("Daniel")
    ]   
)

b1.listar_clientes()
b2.listar_clientes()

print("---")

b2.total_ingresos()

print("---")

b2.clientes[0].depositar(100)
b2.clientes[1].depositar(250)
b2.clientes[2].depositar(500)

b2.total_ingresos()

print("---")
b1.agregar_cliente(Cliente("Pedro"))
b1.clientes[0].depositar(1000)
b1.total_ingresos()

print("---")

b2.clientes[0].depositar(-100)
b2.clientes[0].extraer(-100)
b2.clientes[0].extraer(2500)
