"""
    Visibilidad (miembros de una clase) -> atributos y metodos
    - publico
    - privado

    En python, todos los miembros son publicos.
"""

class Vehiculo:

    codigo_contador = 0

    def __init__(self, marca, modelo, año):
        self.marca = marca
        self.modelo = modelo
        self.año = año

        self._codigo_interno = Vehiculo.codigo_contador
        Vehiculo.codigo_contador += 1

        print(self._codigo_interno)


v1 = Vehiculo("Chevrolet", "Corsa", 1997)
v2 = Vehiculo("Renault", "Sandero", 2010)

print(v1.marca, v1.modelo, v1.año)

v2._codigo_interno = 1234
print(v2._codigo_interno)