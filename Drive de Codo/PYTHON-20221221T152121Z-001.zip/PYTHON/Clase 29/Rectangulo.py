class Rectangulo:
    def __init__(self, ancho, alto):
        self.ancho = ancho
        self.alto = alto

    def area(self):
        return self.ancho * self.alto

    def perimetro(self):
        return self.ancho * 2 + self.alto * 2

    def es_cuadrado(self):
        return self.ancho == self.alto

    def mostrar(self):
        return f"w:{self.ancho} - h:{self.alto}"

    def __str__(self):
        return self.mostrar()

    def __eq__(self, other):
        """
            Dando un comportamiento al operador == entre objetos de tipo Rectangulo.

            Asi como puedo definir el operador ==, puedo definir todos los demas:
            >,< >=, <=, !=
        """
        return self.ancho == other.ancho and self.alto == other.alto

    def comparar_iguales(self, other):
        return self.ancho == other.ancho and self.alto == other.alto

r1 = Rectangulo(10, 10)
r2 = Rectangulo(25, 40)

print(r1.area(), r1.perimetro())
print(r2.area(), r2.perimetro())

print(r1)
print(r1.mostrar())
print(r2)

print("-" * 20)

r3 = Rectangulo(10, 10)
r4 = Rectangulo(10, 10)

print(r3 == r4)
print(r3.comparar_iguales(r4))