class Persona:
    """
        Los docstrings suelen ir debajo de la primera linea de una estructura
        y permite documentarla
    """
    piernas = 2 # Atributo de clase

    def __init__(self, nombre, apellido, edad):
        """
            __init__ es un metodo especial de python.
            En este caso, __init__ es el constructor de las clases.

            Recuerden que el constructor de una clase es una funcion
            que se ejecuta cuando se crea una nueva instancia.
        """
        # Atributos de instancia
        self.nombre = nombre 
        self.apellido = apellido
        self.edad = edad

        print("Se ha creado una nueva persona")

    def saludar(self):
        print(f"Hola soy {self.nombre} {self.apellido} y tengo {self.edad} años")

        # Formas alternativas de mostrar por pantalla lo mismo.
        # print("Hola soy {} {} y tengo {} años".format(self.nombre, self.apellido, self.edad))
        # print("Hola soy " + self.nombre + " " + self.apellido + " y tengo " + str(self.edad) + " años")

    def caminar(self):
        print("Estoy caminando")


persona1 = Persona('Carlos', 'Lopez', 25) # Instanciar una clase y obtener un objeto
persona2 = Persona('Maria', 'Del Cerro', 30)

print("-" * 20)

persona1.saludar()
persona2.saludar()

persona1.caminar()

print(persona1.nombre, persona1.apellido, persona1.edad) #Instancia.atributo
print(Persona.piernas) # Clase.atributo

print("-" * 20)

class Producto:
    pass

producto1 = Producto()

# En tiempo de ejecucion, podemos asignar dinamicamente tanto atributos como metodos
# a un objeto cualquiera.

# Es esto una buena practica?
# En la gran mayoria de los casos NO.
producto1.nombre = "Moto"
producto1.marca = "Mitsubishi"
producto1.precio = 3000.0

print(producto1.nombre)

