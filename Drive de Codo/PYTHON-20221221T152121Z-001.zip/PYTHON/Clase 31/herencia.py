class Bipedo:
    piernas = 2

    def caminar(self):
        print(f"Camiando en {Bipedo.piernas} piernas")


class Persona:
    def __init__(self, nombre, apellido, edad):
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad

    def mostrar(self):
        print(f"Hola soy {self.nombre} {self.apellido}")


class Empleado(Persona):
    def vender(self):
        print(f"{self.nombre} {self.apellido} hizo una venta")

class Cliente(Persona):
    def comprar(self):
        print(f"{self.nombre} {self.apellido} hizo una compra")

class Gerente(Persona, Bipedo):
    def gerenciar(self):
        print(f"{self.nombre} {self.apellido} hizo un tramite administrativo")

e1 = Empleado("Carlos", "Lopez", 25)
c1 = Cliente("Maria", "Del Cerro", 30)
g1 = Gerente("Daniel", "Perez", 45)

e1.mostrar()
c1.mostrar()
g1.mostrar()

e1.vender()
c1.comprar()
g1.gerenciar()
g1.caminar()