# abstract base classes
from abc import ABC, abstractmethod


class Animal(ABC):
    @abstractmethod
    def __init__(self, nombre):
        pass

    @abstractmethod
    def emitir_sonido(self):
        pass


class Perro(Animal):
    def __init__(self, nombre):
        self.nombre = nombre

    def emitir_sonido(self):
        print("Guau")


class Gato(Animal):
    def __init__(self, nombre):
        self.nombre = nombre

    def emitir_sonido(self):
        print("Miau")


class Serpiente(Animal):
    def __init__(self, nombre):
        self.nombre = nombre

    def emitir_sonido(self):
        print("ssss")


class Persona:
    def __init__(self, nombre, apellido, edad):
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad

    def caminar(self):
        print("Caminando")

    def mostrar(self):
        print(self.nombre, self.apellido)

    def emitir_sonido(self):
        print("Hola como estas")

# a1 = Animal() # Esto es lo que queremos evitar

# Polimorfismo
p1 = Perro("Carlitos")
p1.emitir_sonido()

g1 = Gato("Florinda")
g1.emitir_sonido()

s1 = Serpiente("Sebastian")
s1.emitir_sonido()


class Granja:
    def __init__(self, integrantes):
        self.integrantes = integrantes

    def emitir_sonido_integrantes(self):
        for integrante in self.integrantes:
            integrante.emitir_sonido()


granja1 = Granja([
    Perro("Firulais"),
    Gato("Pepito"),
    Serpiente("Sebastian II"),
    Persona("Carlos", "Lopez", 25)
])


print("-" * 10)
granja1.emitir_sonido_integrantes()