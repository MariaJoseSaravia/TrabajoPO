lista_frutas = ["Pera", "Manzana", "Banana"]

def funcion_x(a,b,c):
    print(a * b * c)

for i in range(10):
    print(i ** 2)