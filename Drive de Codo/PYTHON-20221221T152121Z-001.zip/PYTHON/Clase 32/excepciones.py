# Algunas excepciones tipicas

# a = 7 / 0 # ZeroDivisionError
# int("asd") # ValueError
# 2 + "2" # TypeError
# valor = [1,2,3][9] # IndexError

def validar_numero():
    seguir = True

    while seguir:
        try:
            respuesta = int(input("> "))
            seguir = False

        except ValueError as ve:
            print("Ingrese un numero valido", str(ve))

    return respuesta

try:
    a = validar_numero()
    b = validar_numero()

    print(a / b)

except ZeroDivisionError as zde:
    print("Se intentó dividir por 0")

except TypeError as te:
    print("Ocurrió un error de tipos: ", str(te))

finally:
    print("Finally: ")
    print("Adios")


def login():
    print("Bienvenido")
    consultar_bdd()

    print("ya puedes entrar al sistema")

def consultar_bdd():
    try:
        print("Conectando a una base de datos")

        print("Select * from tabla")

        # [1,2,3][9]
    except TypeError as e:
        print("Ocurrio un error: ", str(e))

    finally: # bloque no condicional
        print("Cierro Sesion de base de datos")

login()

print("Adios")