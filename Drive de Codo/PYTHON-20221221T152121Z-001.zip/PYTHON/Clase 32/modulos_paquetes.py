# import paquete1.modulo1
# from paquete1.modulo1 import *
from paquete1.modulo1 import lista_frutas, funcion_x as un_nombre_distinto

from datetime import datetime
import math
import random

print(lista_frutas)

un_nombre_distinto(5,3,1)

print(datetime.now())

print(math.sin(90), math.cos(90))
print(math.pi, math.e)

print(random.random())

for i in range(10):
    print(random.randrange(5, 70))

nombres = ["Carlos", "Maria", "Daniel"]
print(random.choice(nombres))

lista = [1,2,3,4,5,6,7,8,9]
random.shuffle(lista)

print(lista)



