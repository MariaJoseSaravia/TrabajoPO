cadena1 = ""
cadena2 = ''
cadena3 = """
    String multilinea

    Docstrings

    Los strings multilinea tienen 2 usos principales:
    1. Documentar estructuras de código
    2. Comentarios de bloque
"""

print("Hola " + "Como estas")
print(3 + 5)
# print("3" + 5) # Da error
print(int("3") + 5)
print("3" + str(5))

print("A" > "a")

# tamaño de un string
frase = "Hola como estas\n\nAdiós"
print(len(frase))
print(frase)

# acceder a un caracter
print(frase[0]) # Primer elemento
print(frase[-1]) # Ultimo elemento
print(frase[-2]) # Ante ultimo elemento
# print(frase[120]) # Out of range

# Operaciones de Casing

frase2 = "Tres tristes tigres"
print(frase2.upper(), frase2.lower(), frase2.capitalize())

# Slice de strings
print(frase2[0:7])
print(frase2[5:9])
print(frase2[:7])
print(frase2[5:])
print(frase2[:])

# esta?
print("H" in frase2, "H" not in frase2)
print("tristes" in frase2)

for letra in frase2:
    print(letra)

# split y replace
csv = "Pedro;Maria;Carlos" # CSV: Comma Separated Values

print(csv.split(";"))
print(csv.replace(";", "@"))

texto= """Carlos;Lopez;25
    Maria;DelCerro;30
    Daniel;Gomez;56
    Agostina;Perez;45"""

resultados = texto.split("\n")
print(resultados)

for resultado in resultados:
    usuario = resultado.replace(" ", "")
    usuario = usuario.split(";")

    nombre = usuario[0]
    apellido = usuario[1]
    edad = usuario[2]

    # Una forma equivalente de hacer lo mismo que esta arriba:
    # Unpacking
    nombre, apellido, edad = usuario

    print(f"Nombre: {nombre} - Apellido: {apellido} - Edad: {edad}")
    print("Nombre: {} - Apellido: {} - Edad: {}".format(nombre, apellido, edad))

