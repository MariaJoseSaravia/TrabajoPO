# Conjunto de pares clave: valor
# Los diccionarios no tienen orden y tampoco admiten repetidos.
# Los diccionarios son como los objetos de javascript.

diccionario = {}
diccionario2 = dict()

dict_personas = {
    'Carlos': 1234,
    'Maria': 5678,
    'Jose': 9012
}

print(dict_personas['Carlos'])

# Iterando un diccionario
# for each
for clave in dict_personas:
    print(clave, dict_personas[clave])

# usando el .keys()
for clave in dict_personas.keys():
    print(clave, dict_personas[clave])

# .values()
for valor in dict_personas.values():
    print(valor)

# .items()
for elemento in dict_personas.items():
    print(elemento)

# usando unpacking (Metodo preferido)
for clave, valor in dict_personas.items():
    print(clave, valor)

# Agregar un elemento
dict_personas['Pedro'] = 21356
print(dict_personas)

dict_personas['Pedro'] = 5675675
print(dict_personas)

valor_buscado = 5675675

for clave, valor in dict_personas.items():
    if valor == valor_buscado:
        print(clave)


print(len(dict_personas))