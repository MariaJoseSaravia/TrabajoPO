# Las tuplas son colecciones de elementos ordenados. las tuplas son inmutables.

tupla_vacia = ()
tupla_vacia2 = tuple()

tupla_palabras = ("Hola", "Si", "Adios")

# Cualquier accion de lectura es valida
print(tupla_palabras[0]) # Primero
print(tupla_palabras[-1]) # Ultimo
print(tupla_palabras[1:2]) # Slice

# iterar una tupla
for palabra in tupla_palabras:
    print(palabra)

# Cualquier accion de escritura es invalida
# tupla_palabras.append("Pierda") # Error!