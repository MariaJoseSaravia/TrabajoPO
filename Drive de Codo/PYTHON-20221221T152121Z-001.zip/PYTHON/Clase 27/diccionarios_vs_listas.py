persona_1 = {
    'nombre': 'Carlos',
    'apellido': 'Lopez',
    'edad': 25
}

persona_3 = {
    'edad': 35,
    'apellido': 'Gomez',
    'nombre': 'Pedro',
}

persona_2 = [
    'Maria',
    'Del Cerro',
    30
]

persona_4 = [
    40,
    'Daniela',
    'Gonzalez',
]

print("Nombre: {} - Apellido: {} - Edad: {}".format(persona_1['nombre'], persona_1['apellido'], persona_1['edad']))
print("Nombre: {} - Apellido: {} - Edad: {}".format(persona_2[0], persona_2[1], persona_2[2]))
print("Nombre: {} - Apellido: {} - Edad: {}".format(persona_3['nombre'], persona_3['apellido'], persona_3['edad']))
print("Nombre: {} - Apellido: {} - Edad: {}".format(persona_4[0], persona_4[1], persona_4[2]))

print("---------------------------")

alumno1 = {'nombre': 'Lautaro','apellido': 'Gomez','edad': 30}
alumno2 = {'nombre': 'Micaela','apellido': 'Gutierrez','edad': 35}
alumno3 = {'nombre': 'Lucas','apellido': 'Del Prado','edad': 40}

listado_alumnos = [
    alumno1,
    alumno2,
    alumno3
]

for alumno in listado_alumnos:
    print("Nombre: {} - Apellido: {} - Edad: {}".format(alumno['nombre'], alumno['apellido'], alumno['edad']))