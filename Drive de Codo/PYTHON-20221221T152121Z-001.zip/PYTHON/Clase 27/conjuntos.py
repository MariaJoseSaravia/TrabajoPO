# Los conjuntos son colecciones de elementos no ordenados y sin repetidos.

conjunto_vacio = set()
nombres = {'Pedro', 'Juan', 'Martina'}
print(nombres)

# Agregar nueva entrada
nombres.add('Daniel')
print(nombres)

nombres.add('Daniel')
print(nombres)

# Iterar un conjunto
for nombre in nombres:
    print(nombre)

a = {1,2,3,4}
b = {3,4,5,6}

print(a.intersection(b))