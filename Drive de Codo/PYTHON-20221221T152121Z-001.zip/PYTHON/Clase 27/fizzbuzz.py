def fizzbuzz(n):
    for i in range(1, n + 1):
        resultado = i
        if i % 3 == 0:
            resultado = "Fizz"

        if i % 5 == 0:
            resultado = "Buzz"

        if i % 15 == 0:
            resultado = "FizzBuzz"

        print(resultado)

fizzbuzz(100)