# Las listas son colecciones de elementos ordenados. Las listas son Mutables.

# Creando listas
lista_vacia1 = []
lista_vacia2 = list()

lista = [3, 4, 5, 6, 7, 8]
lista2 = ["Holas", 3, 0.5, [1,2,3], True]

# Acceso a un elemento individual
print(lista2[0])
print(lista2[-1])

# Iterando una lista
alumnos = ["Carlos", "Maria", "Pedro"]
alumnos = []

# ver TODOS los alumnos de mi curso
# For "Clasico"
for i in range(0, len(alumnos)):
    print(alumnos[i])

# For each
for alumno in alumnos:
    print(alumno)

# max min y sum
numeros = [1,2,3,4,5,6,7,8,9]
print(max(numeros), min(numeros), sum(numeros))

# esta?
palabras = ["Hola", "Si", "Adios"]
print("Hola" in palabras, "hello" not in palabras)

# Modificar un valor

palabras[0] = "ESTO SI ES UN STRING"
print(palabras)

# Agregar un elemento
# Agregar al final
lista = []

lista.append("Carlos")
lista.append("Maria")
lista.append("Jose")

print(lista)

# Insertar en algun indice valido
lista.insert(1, "Pedro")
print(lista)

# Quitar Elementos
# quitando del final y devolviendo el elemento

elemento = lista.pop()
print(elemento)

elemento = lista.pop()
print(elemento)

print(lista)

# Buscar y quitar
nombres = ["Gaston", "Ludmila", "Godofredo", "Godofredo"]

nombres.remove("Godofredo")
print(nombres)

# Invertir una lista
numeros = [1,2,3,4,5,6,7,8,9]

numeros.reverse() # In place
print(numeros)
 
# Ordenar una lista
numeros2 = [9,1,2,8,3,7,4,6,5]
print(numeros2)

numeros2.sort() # In place
print(numeros2)

numeros2.sort(reverse=True) # In place
print(numeros2)

numeros3 = sorted(numeros2)
print(numeros3)
