const miAplicacion = Vue.createApp({
    components: {},
    data() {
        return {
            kilometros: 0,
            metros: 0,
        }
    },
    watch: {
        kilometros(valor) {
            this.kilometros = valor;
            this.metros = this.kilometros * 1000;
        },

        metros(valor) {
            this.metros = valor;
            this.kilometros = this.metros / 1000;
        }
    }

}).mount("#app");