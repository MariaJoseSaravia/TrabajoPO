const { createApp } = Vue 
createApp({
    data() {
        return {
            frutas: [
                {nombre: "Pera", cantidad: 10, costo: 500.0},
                {nombre: "Manzana", cantidad: 5, costo: 100.0},
                {nombre: "Banana", cantidad: 20, costo: 200.0},
            ],
            nuevaFruta: '',
            cantidadNuevaFruta: 0,
            costoNuevaFruta: 0.0,
            data1: false,
        }
    },
    methods: {
        agregarFruta() {
            if(this.nuevaFruta === ''){
                return;
            }

            for (fruta of this.frutas) {
                if(this.nuevaFruta.toLowerCase() === fruta.nombre.toLowerCase()){
                    fruta.cantidad += this.cantidadNuevaFruta;
                    return;
                }
            }

            this.frutas.push({
                nombre: this.nuevaFruta,
                cantidad: this.cantidadNuevaFruta,
                costo: this.costoNuevaFruta,
            });
        }
    },
    computed: {
        sumarFrutas() {
            this.total = 0;

            for (fruta of this.frutas){
                this.total += fruta.cantidad;
            }

            return this.total;
        },
        promedioFrutas() {
            this.total = 0;

            for (fruta of this.frutas){
                this.total += fruta.costo;
            }

            let resultado = 0;

            if (this.frutas.length != 0) {
                resultado = this.total / this.frutas.length;
            }
            return resultado;
        }
    }
}).mount('#app')