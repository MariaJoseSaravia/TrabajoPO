const { createApp } = Vue 
createApp({
    data() {
        return {
            'mensaje': 'Hola Mundo VUE',
            'curso': 'Codo a Codo comision 22529',
            'desarrollador': 'Carlos Lopez',
            'google_link': 'link',
            'url_google': 'www.google.com.ar',
            'productos': ["ASd", "asd"],
        }
    }
}).mount('#app')