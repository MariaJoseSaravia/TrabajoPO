"use strict"

const numeroLoco = 2;

function multiplicar(a,b){
    let mensaje = 'función multiplicar:';
    let retorno;
    if (a < 0)    
    {      
        retorno = "Escribiste cualquiera";    
    }
    else
    {
        retorno = a * b;
    }

    mensaje= "la nada misma";
    return retorno;
}

var resultado = multiplicar(numeroLoco, 3);

let saludo = "Hola ale";

alert(resultado);
alert(numeroLoco);
//No está definida si esta con el let adentro
alert(mensaje);




// function sumar100(a){
//     return a + 100;
// }

// let sumar100 = a => a + 100;
// alert(sumar100(3));

// function sumar (a, b) {
//     let mensaje = 'función suma:';
//     return mensaje + (a+b);
// }

// alert(sumar(2,3))

// let sumarA = (a,b) => {
//     let mensaje = 'arrow suma:';
//     return mensaje + (a+b);
// }

// alert(sumarA(2,3))



