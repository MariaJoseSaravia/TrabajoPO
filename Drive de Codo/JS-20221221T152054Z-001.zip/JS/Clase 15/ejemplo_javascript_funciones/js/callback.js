function saludar(nombre) {
  alert('Hola ' + nombre);
}

function mandarCoheteLuna(astronauta)
{
  console.log("Se fue el cohete " + astronauta);
}

function procesarEntradaUsuario(callback) {

  /**Banda de codigo */
  if (typeof callback == 'function')
  {
    var nombre = prompt('Por favor ingresa tu nombre.');
    callback(nombre);
  }
  else
  {
    alert("Mandaste cualquiera");
  }
}

procesarEntradaUsuario(saludar);
procesarEntradaUsuario(mandarCoheteLuna);

procesarEntradaUsuario(5); //Esto va a fallar
//alert("Llegué al final")


function cuentaRegresiva(numero){
    if (numero == 0)
    {
      console.log("Llegué a cero");
    }
    else{
      console.log("Estoy en " + numero + " y voy a cero")
      cuentaRegresiva(numero - 1);
    }
}

cuentaRegresiva(10);

let multiplicar = (a, b) => a *b;

console.log(multiplicar(a, b))


