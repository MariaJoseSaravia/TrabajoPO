function saludar(edad) {
    var nombre = prompt("Hola como te llamas?");
    if  (edad > 60){
        alert("Como anda "+ nombre);
    } else {
        alert("Q onda "+ nombre);
    }
}

saludar(39);


