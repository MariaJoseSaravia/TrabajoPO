var txt1 = "Juan";
var txt2 = "Pablo";
var txt3 = txt1 + " " + txt2;
console.log(txt3);
console.log("------------------------------------");

var txt4 = "Bienvenidos ";
txt4 += "a Javascript";
console.log(txt4);
console.log("------------------------------------");

var x = 5 + 5;
var y = "5" + 5;
var z = "Hola" + 5;
console.log(x);
console.log(y);
console.log(z);
console.log("------------------------------------");

