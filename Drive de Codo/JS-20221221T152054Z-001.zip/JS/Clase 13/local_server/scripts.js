
let numeroPosta = 3;
let numeroDeString = Number("3");

// console.log(numeroPosta + 4);
// console.log("3" + "4")
// console.log(Number.parseInt("3") + Number.parseInt("4"))

var miNumero = 2;
console.log("La variable vale: " + miNumero);

let miNumeroLocal = 2;
miNumero = 4;
console.log("La variable vale: " + miNumero);

const PI = 3.14;
// PI = 3.15;

let verdadero = true;
let falso = false;

document.write("<h2>Me meti al final </h2>")

var otroNumero = 3;

var resultado = miNumero +  otroNumero;
console.log("El resultado es " + resultado);



console.log("En un archivo estoy programando..");
alert("Fin archivo");