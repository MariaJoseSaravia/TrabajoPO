var x = 3;
var y = 2;

console.log("x:", x);
console.log("y:", y);
console.log("--------------------------");

x += y; // x = x + y, que es 3 = 3 + 2 o sea 5
console.log("x+y:", x, "(3 + 2 = 5)"); //5
console.log("--------------------------");

x -= y; // x = x - y, que es 5 = 5 - 2 o sea 3
console.log("x-y:", x, "(5 - 2 = 3)"); //3
console.log("--------------------------");

x *= y; // x = x * y, que es 3 = 3 * 2 o sea 6
console.log("x*y:", x, "(3 * 2 = 6)"); //6
console.log("--------------------------");

x /= y; // x = x / y, que es 6 = 6 / 2 o sea 3
console.log("x/y:", x, "(6 / 2 = 3)"); //3
console.log("--------------------------");

x %= y; // x = x % y, que es 3 = 3 % 2 o sea 1
console.log("x%y:", x, "(3 % 2 = 1)"); //1 (con decimal)
console.log("--------------------------");

x = 3;        
x **= y; // x = x ** y, que es 3 = 3 ** 2 o sea 9
console.log("x**y:", x, "(3 ** 2 = 9)"); //9