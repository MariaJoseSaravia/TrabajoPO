/*Bucle FOR*/

// for (inicialización; condición; incremento)
for (i = 0; i < 5; i++) {
    
  console.log("Valor de i:", i);
}

//Otro ejemplo: Mostrar por pantalla los números enteros del 1 a 10.
// for (var i=1; i<=10; i++) {
//   console.log(i);
// }

//Otro ejemplo: Mostrar por pantalla los múltiplos de 2 hasta 100.
// for (var i=2; i<=100; i+=2) {
//   console.log(i);
// }