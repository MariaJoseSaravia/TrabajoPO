from django.db import models


class Alumno(models.Model):
    nombre = models.CharField(
        null=False,
        blank=False,
        max_length=64
    )
    apellido = models.CharField(
        null=False,
        blank=False,
        max_length=64
    )
    edad = models.IntegerField(
        null=False,
        blank=False,
    )

    def __str__(self):
        return f"{self.nombre} {self.apellido} {self.edad}"