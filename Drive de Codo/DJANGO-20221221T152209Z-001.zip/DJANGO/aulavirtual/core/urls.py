from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name="index"),
    path('listar_alumnos', views.listar_alumnos, name="listar_alumnos"),
    path('acerca_de', views.acerca_de, name="acerca_de"),
    path('agregar_alumno', views.agregar_alumno, name="agregar_alumno"),
    path('agregar_alumno_modelform', views.agregar_alumno_modelform, name="agregar_alumno_modelform"),
]