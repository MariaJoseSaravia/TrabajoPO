from django.shortcuts import render
from django.urls import reverse
from django.http import HttpResponseRedirect

from . import forms
from core.models import Alumno


def index(request):
    print(reverse('index'))
    print(reverse('listar_alumnos'))
    print(reverse('acerca_de'))

    contexto = {
        'titulo': 'Bienvenidos al Aula Virtual Codo a codo',
    }
    return render(request, 'core/index.html', contexto)

def listar_alumnos(request):

    alumnos = Alumno.objects.all()

    contexto = {
        'titulo': 'Detalle de alumnos',
        'alumnos': alumnos,
    }

    return render(request, 'core/listar_alumnos.html', contexto)

def acerca_de(request):
    contexto = {
        'titulo': 'Acerca de nosotros'
    }
    return render(request, 'core/acerca_de.html', contexto)

def agregar_alumno(request):
    if request.method == "POST":
        form = forms.AgregarAlumno(request.POST)

        if form.is_valid():
            
            alumno = Alumno(
                nombre = form.cleaned_data['nombre'],
                apellido = form.cleaned_data['apellido'],
                edad = form.cleaned_data['edad'],
            )

            alumno.save()

            return HttpResponseRedirect(reverse("listar_alumnos"))

    else:
        # GET
        form = forms.AgregarAlumno()

    contexto = {
        'titulo': 'Agregar Alumno nuevo',
        'form': form
    }

    return render(request, 'core/agregar_alumno.html', contexto)


def agregar_alumno_modelform(request):

    if request.method == "POST":
        form = forms.FormularioAlumno(request.POST)
        if form.is_valid():

            # Agregar el nuevo alumno a la  BDD
            form.save()

            return HttpResponseRedirect(reverse("listar_alumnos"))

    else:
        # GET
        form = forms.FormularioAlumno()

    contexto = {
        'titulo': 'Agregar Alumno nuevo usando Model Forms',
        'form': form,
    }

    return render(request, 'core/agregar_alumno_modelform.html', contexto)